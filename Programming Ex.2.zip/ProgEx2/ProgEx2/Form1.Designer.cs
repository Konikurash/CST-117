﻿namespace ProgEx2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.animeBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.goodRad = new System.Windows.Forms.RadioButton();
            this.badRad = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.animeCheck = new System.Windows.Forms.CheckBox();
            this.charCheck = new System.Windows.Forms.CheckBox();
            this.align = new System.Windows.Forms.Panel();
            this.show = new System.Windows.Forms.Button();
            this.erase = new System.Windows.Forms.Button();
            this.nameData = new System.Windows.Forms.Label();
            this.charData = new System.Windows.Forms.Label();
            this.boros = new System.Windows.Forms.PictureBox();
            this.genos = new System.Windows.Forms.PictureBox();
            this.nappa = new System.Windows.Forms.PictureBox();
            this.tien = new System.Windows.Forms.PictureBox();
            this.joker = new System.Windows.Forms.PictureBox();
            this.ciel = new System.Windows.Forms.PictureBox();
            this.reaper = new System.Windows.Forms.PictureBox();
            this.karma = new System.Windows.Forms.PictureBox();
            this.rido = new System.Windows.Forms.PictureBox();
            this.kan = new System.Windows.Forms.PictureBox();
            this.nef = new System.Windows.Forms.PictureBox();
            this.killua = new System.Windows.Forms.PictureBox();
            this.sloth = new System.Windows.Forms.PictureBox();
            this.ed = new System.Windows.Forms.PictureBox();
            this.dio = new System.Windows.Forms.PictureBox();
            this.jojo = new System.Windows.Forms.PictureBox();
            this.align.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.boros)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.genos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nappa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.joker)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ciel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reaper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.karma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rido)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nef)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.killua)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sloth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jojo)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select an Anime.";
            // 
            // animeBox
            // 
            this.animeBox.FormattingEnabled = true;
            this.animeBox.Items.AddRange(new object[] {
            "JJBA",
            "FMAB",
            "HxH",
            "VK",
            "AC",
            "OPM",
            "BB",
            "DBZ"});
            this.animeBox.Location = new System.Drawing.Point(56, 52);
            this.animeBox.Name = "animeBox";
            this.animeBox.Size = new System.Drawing.Size(46, 108);
            this.animeBox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Select Alignment";
            // 
            // goodRad
            // 
            this.goodRad.AutoSize = true;
            this.goodRad.Location = new System.Drawing.Point(6, 26);
            this.goodRad.Name = "goodRad";
            this.goodRad.Size = new System.Drawing.Size(51, 17);
            this.goodRad.TabIndex = 3;
            this.goodRad.Text = "Good";
            this.goodRad.UseVisualStyleBackColor = true;
            // 
            // badRad
            // 
            this.badRad.AutoSize = true;
            this.badRad.Location = new System.Drawing.Point(6, 59);
            this.badRad.Name = "badRad";
            this.badRad.Size = new System.Drawing.Size(44, 17);
            this.badRad.TabIndex = 4;
            this.badRad.Text = "Bad";
            this.badRad.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 299);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Description";
            // 
            // animeCheck
            // 
            this.animeCheck.AutoSize = true;
            this.animeCheck.Location = new System.Drawing.Point(44, 328);
            this.animeCheck.Name = "animeCheck";
            this.animeCheck.Size = new System.Drawing.Size(86, 17);
            this.animeCheck.TabIndex = 6;
            this.animeCheck.Text = "Anime Name";
            this.animeCheck.UseVisualStyleBackColor = true;
            // 
            // charCheck
            // 
            this.charCheck.AutoSize = true;
            this.charCheck.Location = new System.Drawing.Point(44, 351);
            this.charCheck.Name = "charCheck";
            this.charCheck.Size = new System.Drawing.Size(103, 17);
            this.charCheck.TabIndex = 7;
            this.charCheck.Text = "Character Name";
            this.charCheck.UseVisualStyleBackColor = true;
            // 
            // align
            // 
            this.align.Controls.Add(this.label2);
            this.align.Controls.Add(this.goodRad);
            this.align.Controls.Add(this.badRad);
            this.align.ForeColor = System.Drawing.Color.Black;
            this.align.Location = new System.Drawing.Point(41, 180);
            this.align.Name = "align";
            this.align.Size = new System.Drawing.Size(106, 100);
            this.align.TabIndex = 8;
            // 
            // show
            // 
            this.show.Location = new System.Drawing.Point(343, 384);
            this.show.Name = "show";
            this.show.Size = new System.Drawing.Size(75, 23);
            this.show.TabIndex = 9;
            this.show.Text = "Show";
            this.show.UseVisualStyleBackColor = true;
            this.show.Click += new System.EventHandler(this.show_Click);
            // 
            // erase
            // 
            this.erase.Location = new System.Drawing.Point(595, 384);
            this.erase.Name = "erase";
            this.erase.Size = new System.Drawing.Size(75, 23);
            this.erase.TabIndex = 10;
            this.erase.Text = "Erase";
            this.erase.UseVisualStyleBackColor = true;
            this.erase.Click += new System.EventHandler(this.erase_Click);
            // 
            // nameData
            // 
            this.nameData.AutoSize = true;
            this.nameData.Location = new System.Drawing.Point(383, 328);
            this.nameData.Name = "nameData";
            this.nameData.Size = new System.Drawing.Size(0, 13);
            this.nameData.TabIndex = 12;
            this.nameData.Visible = false;
            // 
            // charData
            // 
            this.charData.AutoSize = true;
            this.charData.Location = new System.Drawing.Point(383, 351);
            this.charData.Name = "charData";
            this.charData.Size = new System.Drawing.Size(0, 13);
            this.charData.TabIndex = 13;
            this.charData.Visible = false;
            // 
            // boros
            // 
            this.boros.BackColor = System.Drawing.SystemColors.Control;
            this.boros.Image = global::ProgEx2.Properties.Resources.Boros;
            this.boros.Location = new System.Drawing.Point(249, 27);
            this.boros.Name = "boros";
            this.boros.Size = new System.Drawing.Size(462, 285);
            this.boros.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.boros.TabIndex = 28;
            this.boros.TabStop = false;
            this.boros.Visible = false;
            // 
            // genos
            // 
            this.genos.BackColor = System.Drawing.SystemColors.Control;
            this.genos.Image = global::ProgEx2.Properties.Resources.Genos;
            this.genos.Location = new System.Drawing.Point(249, 27);
            this.genos.Name = "genos";
            this.genos.Size = new System.Drawing.Size(462, 285);
            this.genos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.genos.TabIndex = 27;
            this.genos.TabStop = false;
            this.genos.Visible = false;
            // 
            // nappa
            // 
            this.nappa.BackColor = System.Drawing.SystemColors.Control;
            this.nappa.Image = global::ProgEx2.Properties.Resources.Nappa;
            this.nappa.Location = new System.Drawing.Point(249, 27);
            this.nappa.Name = "nappa";
            this.nappa.Size = new System.Drawing.Size(462, 285);
            this.nappa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.nappa.TabIndex = 26;
            this.nappa.TabStop = false;
            this.nappa.Visible = false;
            // 
            // tien
            // 
            this.tien.BackColor = System.Drawing.SystemColors.Control;
            this.tien.Image = global::ProgEx2.Properties.Resources.Tien_Shinhan;
            this.tien.Location = new System.Drawing.Point(249, 27);
            this.tien.Name = "tien";
            this.tien.Size = new System.Drawing.Size(462, 285);
            this.tien.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tien.TabIndex = 25;
            this.tien.TabStop = false;
            this.tien.Visible = false;
            // 
            // joker
            // 
            this.joker.BackColor = System.Drawing.SystemColors.Control;
            this.joker.Image = global::ProgEx2.Properties.Resources.Joker;
            this.joker.Location = new System.Drawing.Point(249, 27);
            this.joker.Name = "joker";
            this.joker.Size = new System.Drawing.Size(462, 285);
            this.joker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.joker.TabIndex = 24;
            this.joker.TabStop = false;
            this.joker.Visible = false;
            // 
            // ciel
            // 
            this.ciel.BackColor = System.Drawing.SystemColors.Control;
            this.ciel.Image = global::ProgEx2.Properties.Resources.Ciel;
            this.ciel.Location = new System.Drawing.Point(249, 27);
            this.ciel.Name = "ciel";
            this.ciel.Size = new System.Drawing.Size(462, 285);
            this.ciel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ciel.TabIndex = 23;
            this.ciel.TabStop = false;
            this.ciel.Visible = false;
            // 
            // reaper
            // 
            this.reaper.BackColor = System.Drawing.SystemColors.Control;
            this.reaper.Image = global::ProgEx2.Properties.Resources.Reaper;
            this.reaper.Location = new System.Drawing.Point(249, 27);
            this.reaper.Name = "reaper";
            this.reaper.Size = new System.Drawing.Size(462, 285);
            this.reaper.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.reaper.TabIndex = 22;
            this.reaper.TabStop = false;
            this.reaper.Visible = false;
            // 
            // karma
            // 
            this.karma.BackColor = System.Drawing.SystemColors.Control;
            this.karma.Image = global::ProgEx2.Properties.Resources.Karma;
            this.karma.Location = new System.Drawing.Point(249, 27);
            this.karma.Name = "karma";
            this.karma.Size = new System.Drawing.Size(462, 285);
            this.karma.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.karma.TabIndex = 21;
            this.karma.TabStop = false;
            this.karma.Visible = false;
            // 
            // rido
            // 
            this.rido.BackColor = System.Drawing.SystemColors.Control;
            this.rido.Image = global::ProgEx2.Properties.Resources.Rido_Kuran;
            this.rido.Location = new System.Drawing.Point(249, 27);
            this.rido.Name = "rido";
            this.rido.Size = new System.Drawing.Size(462, 285);
            this.rido.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rido.TabIndex = 20;
            this.rido.TabStop = false;
            this.rido.Visible = false;
            // 
            // kan
            // 
            this.kan.BackColor = System.Drawing.SystemColors.Control;
            this.kan.Image = global::ProgEx2.Properties.Resources.Kaname;
            this.kan.Location = new System.Drawing.Point(249, 27);
            this.kan.Name = "kan";
            this.kan.Size = new System.Drawing.Size(462, 285);
            this.kan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.kan.TabIndex = 19;
            this.kan.TabStop = false;
            this.kan.Visible = false;
            // 
            // nef
            // 
            this.nef.BackColor = System.Drawing.SystemColors.Control;
            this.nef.Image = global::ProgEx2.Properties.Resources.Neferpitou;
            this.nef.Location = new System.Drawing.Point(249, 27);
            this.nef.Name = "nef";
            this.nef.Size = new System.Drawing.Size(462, 285);
            this.nef.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.nef.TabIndex = 18;
            this.nef.TabStop = false;
            this.nef.Visible = false;
            // 
            // killua
            // 
            this.killua.BackColor = System.Drawing.SystemColors.Control;
            this.killua.Image = global::ProgEx2.Properties.Resources.Killua;
            this.killua.Location = new System.Drawing.Point(249, 27);
            this.killua.Name = "killua";
            this.killua.Size = new System.Drawing.Size(462, 285);
            this.killua.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.killua.TabIndex = 17;
            this.killua.TabStop = false;
            this.killua.Visible = false;
            // 
            // sloth
            // 
            this.sloth.BackColor = System.Drawing.SystemColors.Control;
            this.sloth.Image = global::ProgEx2.Properties.Resources.sloth;
            this.sloth.Location = new System.Drawing.Point(249, 27);
            this.sloth.Name = "sloth";
            this.sloth.Size = new System.Drawing.Size(462, 285);
            this.sloth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sloth.TabIndex = 16;
            this.sloth.TabStop = false;
            this.sloth.Visible = false;
            // 
            // ed
            // 
            this.ed.BackColor = System.Drawing.SystemColors.Control;
            this.ed.Image = global::ProgEx2.Properties.Resources.win;
            this.ed.Location = new System.Drawing.Point(249, 27);
            this.ed.Name = "ed";
            this.ed.Size = new System.Drawing.Size(462, 285);
            this.ed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ed.TabIndex = 15;
            this.ed.TabStop = false;
            this.ed.Visible = false;
            // 
            // dio
            // 
            this.dio.BackColor = System.Drawing.SystemColors.Control;
            this.dio.Image = global::ProgEx2.Properties.Resources.dio;
            this.dio.Location = new System.Drawing.Point(249, 27);
            this.dio.Name = "dio";
            this.dio.Size = new System.Drawing.Size(462, 285);
            this.dio.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dio.TabIndex = 14;
            this.dio.TabStop = false;
            this.dio.Visible = false;
            // 
            // jojo
            // 
            this.jojo.BackColor = System.Drawing.SystemColors.Control;
            this.jojo.Image = global::ProgEx2.Properties.Resources.JosephJoestar123;
            this.jojo.Location = new System.Drawing.Point(249, 27);
            this.jojo.Name = "jojo";
            this.jojo.Size = new System.Drawing.Size(462, 285);
            this.jojo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.jojo.TabIndex = 11;
            this.jojo.TabStop = false;
            this.jojo.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.boros);
            this.Controls.Add(this.genos);
            this.Controls.Add(this.nappa);
            this.Controls.Add(this.tien);
            this.Controls.Add(this.joker);
            this.Controls.Add(this.ciel);
            this.Controls.Add(this.reaper);
            this.Controls.Add(this.karma);
            this.Controls.Add(this.rido);
            this.Controls.Add(this.kan);
            this.Controls.Add(this.nef);
            this.Controls.Add(this.killua);
            this.Controls.Add(this.sloth);
            this.Controls.Add(this.ed);
            this.Controls.Add(this.dio);
            this.Controls.Add(this.charData);
            this.Controls.Add(this.nameData);
            this.Controls.Add(this.jojo);
            this.Controls.Add(this.erase);
            this.Controls.Add(this.show);
            this.Controls.Add(this.align);
            this.Controls.Add(this.charCheck);
            this.Controls.Add(this.animeCheck);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.animeBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.align.ResumeLayout(false);
            this.align.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.boros)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.genos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nappa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.joker)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ciel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reaper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.karma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rido)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nef)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.killua)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sloth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jojo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox animeBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton goodRad;
        private System.Windows.Forms.RadioButton badRad;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox animeCheck;
        private System.Windows.Forms.CheckBox charCheck;
        private System.Windows.Forms.Panel align;
        private System.Windows.Forms.Button show;
        private System.Windows.Forms.Button erase;
        private System.Windows.Forms.PictureBox jojo;
        private System.Windows.Forms.Label nameData;
        private System.Windows.Forms.Label charData;
        private System.Windows.Forms.PictureBox dio;
        private System.Windows.Forms.PictureBox ed;
        private System.Windows.Forms.PictureBox sloth;
        private System.Windows.Forms.PictureBox killua;
        private System.Windows.Forms.PictureBox nef;
        private System.Windows.Forms.PictureBox kan;
        private System.Windows.Forms.PictureBox rido;
        private System.Windows.Forms.PictureBox karma;
        private System.Windows.Forms.PictureBox reaper;
        private System.Windows.Forms.PictureBox ciel;
        private System.Windows.Forms.PictureBox joker;
        private System.Windows.Forms.PictureBox tien;
        private System.Windows.Forms.PictureBox nappa;
        private System.Windows.Forms.PictureBox genos;
        private System.Windows.Forms.PictureBox boros;
    }
}


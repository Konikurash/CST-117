﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgEx2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void show_Click(object sender, EventArgs e)
        {
            jojo.Visible = true;
            if (animeCheck.Checked) {
                nameData.Visible = true;
            }
            if (charCheck.Checked)
            {
                charData.Visible = true;
            }

            String anime;
            anime = animeBox.SelectedItem.ToString();
            if (anime == "JJBA")
            {
                nameData.Text = "JoJo's Bizzare Adventure";
                if (goodRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    jojo.Visible = true;
                    charData.Text = "Joseph Joestar";
                }
                else if (badRad.Checked) {
                    jojo.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    dio.Visible = true;
                    charData.Text = "Dio Brando";
                }
            }
            if (anime == "FMAB")
            {
                nameData.Text = "Fullmetal Alchemist: Brotherhood";
                if (goodRad.Checked)
                {
                    dio.Visible = false;
                    jojo.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    ed.Visible = true;
                    charData.Text = "Edward Elric";
                }
                else if (badRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    jojo.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    sloth.Visible = true;
                    charData.Text = "Sloth";
                }
            }
            if (anime == "HxH")
            {
                nameData.Text = "Hunter x Hunter";
                if (goodRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    jojo.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    killua.Visible = true;
                    charData.Text = "Killua Zoldyck";
                }
                else if (badRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    jojo.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    nef.Visible = true;
                    charData.Text = "Neferpitou";
                }
            }
            if (anime == "VK")
            {
                nameData.Text = "Vampire Knight";
                if (goodRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    jojo.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    kan.Visible = true;
                    charData.Text = "Kaname Kuran";
                }
                else if (badRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    jojo.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    rido.Visible = true;
                    charData.Text = "Rido Kuran";
                }
            }
            if (anime == "AC")
            {
                nameData.Text = "Assassination Classroom";
                if (goodRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    jojo.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    karma.Visible = true;
                    charData.Text = "Karma Akabane";
                }
                else if (badRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    jojo.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    reaper.Visible = true;
                    charData.Text = "The Reaper";
                }
            }
            if (anime == "OPM")
            {
                nameData.Text = "One Punch Man";
                if (goodRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    jojo.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    genos.Visible = true;
                        charData.Text = "Genos";
                }
                else if (badRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    jojo.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    boros.Visible = true;
                        charData.Text = "Lord Boros";
                }
            }
            if (anime == "BB")
            {
                nameData.Text = "Black Butler";
                if (goodRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    jojo.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    ciel.Visible = true;
                    charData.Text = "Ciel Phantomhive";
                }
                else if (badRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    jojo.Visible = false;
                    tien.Visible = false;
                    nappa.Visible = false;

                    joker.Visible = true;
                    charData.Text = "Joker";
                }
            }
            if (anime == "DBZ")
            {
                nameData.Text = "Dragon Ball Z";
                if (goodRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    jojo.Visible = false;
                    nappa.Visible = false;

                    tien.Visible = true;
                    charData.Text = "Tien Shinhan";
                }
                else if (badRad.Checked)
                {
                    dio.Visible = false;
                    ed.Visible = false;
                    sloth.Visible = false;
                    killua.Visible = false;
                    nef.Visible = false;
                    kan.Visible = false;
                    rido.Visible = false;
                    karma.Visible = false;
                    reaper.Visible = false;
                    genos.Visible = false;
                    boros.Visible = false;
                    ciel.Visible = false;
                    joker.Visible = false;
                    tien.Visible = false;
                    jojo.Visible = false;

                    nappa.Visible = true;
                    charData.Text = "Nappa";
                }
            }
        }

        private void erase_Click(object sender, EventArgs e)
        {
            jojo.Visible = false;
            dio.Visible = false;
            ed.Visible = false;
            sloth.Visible = false;
            killua.Visible = false;
            nef.Visible = false;
            kan.Visible = false;
            rido.Visible = false;
            karma.Visible = false;
            reaper.Visible = false;
            genos.Visible = false;
            boros.Visible = false;
            ciel.Visible = false;
            joker.Visible = false;
            tien.Visible = false;
            nappa.Visible = false;
            charData.Visible = false;
            nameData.Visible = false;
        }
    }
}
